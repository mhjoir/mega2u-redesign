# mega2u.com — إعادة تصميم باقي أجزاء الموقع بأسلوب Kinguin (RTL)

هذا التسليم يحتوي على إعادة تصميم كاملة لباقي أجزاء الموقع (ما عدا بطاقات المنتجات وصفحة تفاصيل المنتج التي تم إنجازها سابقاً).

## 📦 الملفات المُسلَّمة

| الملف | المسار في مشروعك |
|---|---|
| `Header.tsx` | `src/components/Header.tsx` |
| `Footer.tsx` | `src/components/Footer.tsx` |
| `Hero.tsx` | `src/components/Hero.tsx` |
| `FeaturesSection.tsx` | `src/components/FeaturesSection.tsx` |
| `TestimonialsSection.tsx` | `src/components/TestimonialsSection.tsx` |
| `CTASection.tsx` | `src/components/CTASection.tsx` |
| `Login.tsx` | `src/pages/Login.tsx` *(جديد)* |
| `Register.tsx` | `src/pages/Register.tsx` *(جديد)* |
| `CustomerPortal.tsx` | `src/pages/CustomerPortal.tsx` |
| `Cart.tsx` | `src/pages/Cart.tsx` *(جديد)* |
| `Checkout.tsx` | `src/pages/Checkout.tsx` |
| `App.tsx` | `src/App.tsx` *(تحديث المسارات فقط)* |
| `index.css` | `src/index.css` *(توكنات Kinguin)* |

## ⚠️ ملفات لم يتم المساس بها (كما طلبت)
- `src/components/ProductCard.tsx`
- `src/components/ProductsSection.tsx`
- `src/pages/ProductPage.tsx`
- `src/lib/products.ts`
- جميع ملفات السياسات (Terms, Privacy, Refund)

## 🚀 خطوات الدمج

1. انسخ الملفات إلى المسارات المطابقة في مشروعك.
2. أضف المسارات الجديدة في `App.tsx`:
   ```tsx
   import Login from "./pages/Login";
   import Register from "./pages/Register";
   import Cart from "./pages/Cart";

   <Route path="/login" component={Login} />
   <Route path="/register" component={Register} />
   <Route path="/cart" component={Cart} />
   ```
3. تأكّد من وجود خط Cairo في `index.html` (يتم استيراده تلقائياً عبر `index.css`).
4. لا حاجة لتثبيت أي حزم جديدة — المشروع يستخدم نفس مكتبات الإصدار السابق.

## 🎨 نظام التصميم الموحد

جميع الصفحات الجديدة تشترك في نفس نظام التصميم مع بطاقات المنتجات السابقة:

| العنصر | القيمة |
|---|---|
| **اللون الأساسي** | `#ff6b35` (برتقالي Kinguin) |
| **اللون الثانوي** | `#011627` (Navy داكن) |
| **خلفية الصفحة** | `#f5f6fa` |
| **حدود ناعمة** | `#e7eaf3` |
| **الخط الأساسي** | Cairo (للعربية) |
| **زاوية الانحناء** | `0.75rem` للأزرار، `1rem` للبطاقات |
| **الحاوية** | `.kg-container` (max-width: 1320px) |

## 🧩 Utility Classes جاهزة (في index.css)

- `.kg-container` — حاوية بعرض موحد
- `.kg-card` — بطاقة بيضاء بحدود ناعمة + تأثير hover
- `.kg-btn` + `.kg-btn-primary` / `.kg-btn-dark` / `.kg-btn-outline` / `.kg-btn-ghost`
- `.kg-input` — حقل إدخال بأسلوب Kinguin
- `.kg-link` — رابط داخل النص
- `.kg-discount-badge` — شارة الخصم
- `.kg-glow` — توهج الأزرار الرئيسية

## ✅ ضمانات الالتزام

- **لم يُعدَّل أي محتوى نصي** — جميع النصوص الموجودة محفوظة كما هي.
- **لم تُعدَّل بنية البيانات** — البطاقات الموجودة في `lib/products.ts` تعمل كما هي.
- **متوافق مع API الحالي** — جميع الصفحات تتوقّع نفس مصادر البيانات.
- **RTL أصلي** — كل الصفحات تستخدم `dir="rtl"` مع تخطيطات منعكسة بشكل صحيح.
- **متجاوب بالكامل**: موبايل / تابلت / ديسكتوب.
- **شريط BACKEND**: لم يتم لمس مجلد `server/` ولا قواعد البيانات.

## 🔌 نقاط التكامل المقترحة (لفريقك التقني)

في الصفحات التالية أُبقيت `// TODO` تعليقات في الأماكن التي يجب فيها استبدال المحاكاة بـ API الحقيقي:
- `Login.tsx` → استبدل `setTimeout` بطلب `POST /api/auth/login`
- `Register.tsx` → استبدل `setTimeout` بطلب `POST /api/auth/register`
- `Checkout.tsx` → استبدل `setTimeout` بطلب `POST /api/orders`
- `Cart.tsx` → الحالة الحالية محلية (state)؛ اربطها بـ context أو store الخاص بك.
